<?php
/*
use DAO\api as api;

$themoviedb = new api();

//$string = json_encode($themoviedb->getNowPlayingMovies());
echo $themoviedb->getNowPlayingMovies();
*/


use DAO\UserRepository as UserRepository;

$pruebaUR = new UserRepository;

$pruebaUR->retrieveData();
$pruebaUR->toString();
?>