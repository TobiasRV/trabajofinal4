<html>

<form id="signup" action="" method="POST">
    <input type="text" name="user" id="name" placeholder="User">
    <input type="password" name="password" id="password" placeholder="Password">
    <input type="text" name="firstname" id="firstname" placeholder="First Name">
    <input type="text" name="lastname" id="lastname" placeholder="Last Name">
    <input type="email" name="email" id="email" placeholder="Email">
    <button type="submit" id="login-submit">SIGN UP</button>
</form>



</html>