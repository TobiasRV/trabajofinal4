<?php namespace Views;

include_once(VIEWS_PATH . "header.php");
include_once(VIEWS_PATH . "nav.php");
include_once(VIEWS_PATH . "upcomingslider.php");
?>

