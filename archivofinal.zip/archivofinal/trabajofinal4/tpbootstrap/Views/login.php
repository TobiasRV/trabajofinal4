<html>

<form id="login" action="" method="POST">
    <input type="text" name="user" id="name" placeholder="User">
    <input type="password" name="password" id="password" placeholder="Password">
    <button type="submit" id="login-submit">LOGIN</button>
</form>


</html>