<?php namespace Config;

define("ROOT",dirname(__DIR__) . "/");
define("FRONT_ROOT", "http://localhost/archivofinal/trabajofinal4/tpbootstrap"); // ACA HAY QUE CAMBIAR LA RUTA RELATIVA AL DIRECTORIO ROOT.
define("VIEWS_PATH","Views/");
define("CSS_PATH", FRONT_ROOT.VIEWS_PATH . "css/");
define("JS_PATH", FRONT_ROOT.VIEWS_PATH . "js/");

